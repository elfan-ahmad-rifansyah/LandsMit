package id.dwiilham.landsmit.callback

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class MetaInfo {

    @SerializedName("Timestamp")
    @Expose
    private var timestamp: String? = null
    @SerializedName("NextPageInformation")
    @Expose
    private var nextPageInformation: String? = null

    fun getTimestamp(): String? {
        return timestamp
    }

    fun setTimestamp(timestamp: String?) {
        this.timestamp = timestamp
    }

    fun getNextPageInformation(): String? {
        return nextPageInformation
    }

    fun setNextPageInformation(nextPageInformation: String?) {
        this.nextPageInformation = nextPageInformation
    }
}