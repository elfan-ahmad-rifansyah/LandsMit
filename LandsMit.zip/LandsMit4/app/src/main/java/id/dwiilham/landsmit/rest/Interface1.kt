package id.dwiilham.landsmit.rest

import id.dwiilham.landsmit.callback.Example
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Query

interface Interface1 {
    @POST("messages")
    fun getInfo(
        @Header("x-api-key") key: String,
        @Query("msisdn") msisdn: String,
        @Query("content") content: String
    ): Call<Bigbox>?
}