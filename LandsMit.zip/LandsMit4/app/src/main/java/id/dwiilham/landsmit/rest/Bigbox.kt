package id.dwiilham.landsmit.rest

import com.google.gson.annotations.SerializedName

class Bigbox {

    @SerializedName("code")
    var code: String? = null
    @SerializedName("status")
    var status: String? = null
    @SerializedName("message")
    var message: String? = null
    @SerializedName("msgid")
    var msgid: String? = null

}
