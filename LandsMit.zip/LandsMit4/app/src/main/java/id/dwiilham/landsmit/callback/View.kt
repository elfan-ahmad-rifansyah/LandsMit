package id.dwiilham.landsmit.callback

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class View {

    @SerializedName("_type")
    @Expose
    private var type: String? = null
    @SerializedName("ViewId")
    @Expose
    private var viewId: Int? = null
    @SerializedName("Result")
    @Expose
    private var result: List<Result?>? = null

    fun getType(): String? {
        return type
    }

    fun setType(type: String?) {
        this.type = type
    }

    fun getViewId(): Int? {
        return viewId
    }

    fun setViewId(viewId: Int?) {
        this.viewId = viewId
    }

    fun getResult(): List<Result?>? {
        return result
    }

    fun setResult(result: List<Result?>?) {
        this.result = result
    }

}