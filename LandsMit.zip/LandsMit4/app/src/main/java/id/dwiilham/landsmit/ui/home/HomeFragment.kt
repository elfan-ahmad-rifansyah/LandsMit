package id.dwiilham.landsmit.ui.home

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.PermissionChecker.checkSelfPermission
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.google.android.gms.location.LocationServices
import id.dwiilham.landsmit.R
import id.co.telkom.iot.AntaresHTTPAPI;
import id.co.telkom.iot.AntaresResponse;
import id.dwiilham.landsmit.BeritaActivity
import id.dwiilham.landsmit.BpbdActivity
import id.dwiilham.landsmit.callback.Example
import id.dwiilham.landsmit.rest.RestAdapter
import id.dwiilham.landsmit.rest.RestInterface
import kotlinx.android.synthetic.main.app_bar_main.*
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.lang.Exception
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import kotlin.properties.Delegates

class HomeFragment : Fragment(), AntaresHTTPAPI.OnResponseListener {

    private lateinit var view1: LinearLayout
    private lateinit var view2: LinearLayout
    private lateinit var antaresAPIHTTP: AntaresHTTPAPI
    private lateinit var dataDevice: String
    private lateinit var nilaiGetaran: TextView
    private lateinit var txtCuaca: TextView
    private lateinit var txtLocation: TextView
    private lateinit var txtSuhu: TextView
    private lateinit var kemiringan: TextView
    private lateinit var img1: ImageView
    private lateinit var img2: ImageView
    private lateinit var txtWaktu: TextView
    private lateinit var txtCity: TextView
    private lateinit var txtSubDistrict: TextView
    private lateinit var beritaLayout: LinearLayout
    private lateinit var bpbdLayout: LinearLayout
    private var satuSatu = 0

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_home, container, false)

        view1 = root.findViewById(R.id.view1)
        view2 = root.findViewById(R.id.view2)
        antaresAPIHTTP = AntaresHTTPAPI()
        antaresAPIHTTP.addListener(this)
        nilaiGetaran = root.findViewById(R.id.textView19)
        txtCuaca = root.findViewById(R.id.cuaca)
        txtLocation = root.findViewById(R.id.textView5)
        txtSuhu = root.findViewById(R.id.suhu)
        kemiringan = root.findViewById(R.id.textView15)
        img1 = root.findViewById(R.id.imageView3)
        img2 = root.findViewById(R.id.imageView2)
        txtWaktu = root.findViewById(R.id.textView9)
        txtCity = root.findViewById(R.id.textView3)
        txtSubDistrict = root.findViewById(R.id.textView2)
        beritaLayout = root.findViewById(R.id.beritaLayout)
        bpbdLayout = root.findViewById(R.id.bpbdLayout)

        beritaLayout.setOnClickListener {
            val intent = Intent(context, BeritaActivity::class.java)
            startActivity(intent)
        }

        bpbdLayout.setOnClickListener {
            val intent = Intent(context, BpbdActivity::class.java)
            startActivity(intent)
        }



        return root
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onStart() {
        super.onStart()

        var runnable = Runnable {  }
        val handler = Handler()
        val delay = 5000
        handler.postDelayed(Runnable {
            activity?.runOnUiThread {
                handler.postDelayed(runnable, delay.toLong())

                val currentDateTime = LocalDateTime.now()


                txtWaktu.text = currentDateTime.format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.FULL, FormatStyle.MEDIUM))

                val cm = context?.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val activeNetwork: NetworkInfo? = cm.activeNetworkInfo

                val isConnected: Boolean = activeNetwork?.isConnectedOrConnecting == true

                if (activeNetwork?.isAvailable!!) {
                    val location = context?.let { LocationServices.getFusedLocationProviderClient(it) }
                    location?.lastLocation?.addOnSuccessListener {
                        Log.d("location", it.longitude.toString() + " Latitude: " + it.latitude.toString())

                        val api = RestAdapter().client?.create(RestInterface::class.java)
                        val posi: String = it.latitude.toString() + "," + it.longitude.toString() + ",250"
                        val call: Call<Example>? = api?.getInfo(
                            prox = posi,
                            mode = "retrieveAddresses",
                            maxResult = "1",
                            gen = "9",
                            appId = "9fqnaB6d6rLJWxFpNASK",
                            appCode = "RoB26jtN0zFQ1BBhPdJe2A"
                        )

                        call?.enqueue(object : Callback<Example> {
                            override fun onFailure(call: Call<Example>?, t: Throwable?) {
                                Toast.makeText(context, "terjadi kesalahan!", Toast.LENGTH_LONG).show()
                                Log.e("MainActivity", t.toString())
                            }

                            override fun onResponse(
                                call: Call<Example>?,
                                response: Response<Example>?
                            ) {
                                if (response != null) {
                                    if (response.isSuccessful) {
                                        when(response.code()) {
                                            200 -> {
                                                txtCity.text = response.body().getResponse()?.getView()?.get(0)?.getResult()?.get(0)?.getLocation()?.getAddress()?.getLabel()
                                                txtSubDistrict.text = response.body().getResponse()?.getView()?.get(0)?.getResult()?.get(0)?.getLocation()?.getAddress()?.getSubdistrict()
                                            }
                                            else -> {
                                                txtLocation.text = "ERROR"
                                            }
                                        }
                                    } else {
                                        txtLocation.text = response.raw().toString()
                                        try {
                                            val jObjError: JSONObject = JSONObject(response.errorBody().string())
                                            Toast.makeText(context, jObjError.getJSONObject("error").getString("message") + " 1", Toast.LENGTH_LONG).show()
                                        } catch (e: Exception) {
                                            Toast.makeText(context, e.message + " 2", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }
                            }

                        })

                        //txtLocation.text = it.longitude.toString() + " Latitude: " + it.latitude.toString()
                    }

                    location?.lastLocation?.addOnFailureListener {
                        Log.d("error loc", it.toString())
                    }


                    antaresAPIHTTP.getLatestDataofDevice("0f1859c20d87b077:afcab3db1a3ab4a1", "PosFic", "Posfic")
                } else {
                    if (satuSatu > 0) {
                        Log.d("INTERNET", "Tidak ada koneksi internet")
                    } else {
                        Toast.makeText(context, "Tidak ada koneksi internet", Toast.LENGTH_LONG).show()
                    }

                }



            }

        }.also { runnable = it }, delay.toLong())
    }

    override fun onResponse(p0: AntaresResponse?) {
        if (p0 != null) {
            if (p0.requestCode == 0) {
                try {
                    var body1: JSONObject = JSONObject(p0.body)
                    dataDevice = body1.getJSONObject("m2m:cin").getString("con")
                    var body: JSONObject = JSONObject(dataDevice)

                    activity?.runOnUiThread {
                        try {
                            var nilai: Double = body.get("Gx").toString().toDouble()
                            nilaiGetaran.text = String.format("%.3f", nilai)
                            txtCuaca.text = body.get("Cuaca").toString()
                            txtSuhu.text = body.get("T").toString() + "°C"
                            var nilaiKemiringan = body.get("Gy").toString().toDouble()
                            kemiringan.text = String.format("%.2f", nilaiKemiringan)
                            view1.visibility = View.GONE
                            view2.visibility = View.VISIBLE
                            if (body.get("Cuaca").toString() == "Tidak Hujan") {
                                img1.visibility = View.VISIBLE
                                img2.visibility = View.GONE
                            } else {
                                img2.visibility = View.VISIBLE
                                img1.visibility = View.GONE
                            }
                        } catch (e: JSONException) {
                            e.printStackTrace()
                        }
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        Handler().removeCallbacksAndMessages(null);
    }
}