package id.dwiilham.landsmit

import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageView
import androidx.annotation.RequiresApi

class BeritaActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_berita)

        supportActionBar?.hide()

        val webview1: WebView = findViewById(R.id.webview1)

        findViewById<ImageView>(R.id.imageView8).setOnClickListener {
            finish()
        }

        webview1.settings.javaScriptEnabled = true

        webview1.webViewClient = object : WebViewClient() {
            @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                if (request != null) {
                    view?.loadUrl(request.url.toString())
                }
                return true
            }
        }

        webview1.loadUrl("https://www.kompas.com/tag/bencana-alam")
    }
}
