package id.dwiilham.landsmit

import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageView
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.app_bar_main.*

class BpbdActivity : AppCompatActivity() {

    @RequiresApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bpbd)

        val webview2: WebView = findViewById(R.id.webview2)

        supportActionBar?.hide()

        findViewById<ImageView>(R.id.imageView4).setOnClickListener {
            finish()
        }

        webview2.settings.javaScriptEnabled = true

        webview2.webViewClient = object : WebViewClient() {
            @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                if (request != null) {
                    view?.loadUrl(request.url.toString())
                }
                return true
            }
        }

        webview2.loadUrl("https://bpbd.jakarta.go.id/")
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return super.onSupportNavigateUp()
    }
}
