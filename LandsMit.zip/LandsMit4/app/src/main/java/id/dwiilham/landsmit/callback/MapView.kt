package id.dwiilham.landsmit.callback

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class MapView {
    @SerializedName("TopLeft")
    @Expose
    private var topLeft: TopLeft? = null
    @SerializedName("BottomRight")
    @Expose
    private var bottomRight: BottomRight? = null

    fun getTopLeft(): TopLeft? {
        return topLeft
    }

    fun setTopLeft(topLeft: TopLeft?) {
        this.topLeft = topLeft
    }

    fun getBottomRight(): BottomRight? {
        return bottomRight
    }

    fun setBottomRight(bottomRight: BottomRight?) {
        this.bottomRight = bottomRight
    }
}