package id.dwiilham.landsmit.rest

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RestAdapter {

    private var retrofit: Retrofit? = null

    val client: Retrofit?
        get() {
            if (retrofit == null) {
                val BASE_URL = "https://reverse.geocoder.api.here.com/6.2/"
                retrofit = Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
            }

            return retrofit
        }
}