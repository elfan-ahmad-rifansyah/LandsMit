package id.dwiilham.landsmit.callback

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

class AdditionalDatum {
    @SerializedName("value")
    @Expose
    private var value: String? = null
    @SerializedName("key")
    @Expose
    private var key: String? = null

    fun getValue(): String? {
        return value
    }

    fun setValue(value: String?) {
        this.value = value
    }

    fun getKey(): String? {
        return key
    }

    fun setKey(key: String?) {
        this.key = key
    }
}