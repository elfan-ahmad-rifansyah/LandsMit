package id.dwiilham.landsmit.callback

import com.google.gson.annotations.SerializedName

class ResultsCallback {

    @SerializedName("Location")
    var location: List<LocCallback>? = null

}
