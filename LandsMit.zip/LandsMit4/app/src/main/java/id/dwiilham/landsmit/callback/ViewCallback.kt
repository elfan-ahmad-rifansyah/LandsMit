package id.dwiilham.landsmit.callback

import com.google.gson.annotations.SerializedName

class ViewCallback {

    @SerializedName("Result")
    var result: List<ResultsCallback>? = null

}
