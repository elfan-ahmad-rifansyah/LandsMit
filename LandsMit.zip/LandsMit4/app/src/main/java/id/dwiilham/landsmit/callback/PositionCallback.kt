package id.dwiilham.landsmit.callback

import com.google.gson.annotations.SerializedName
import org.json.JSONObject

class PositionCallback {

    @SerializedName("Response")
    var response: ViewCallback? = null

}
