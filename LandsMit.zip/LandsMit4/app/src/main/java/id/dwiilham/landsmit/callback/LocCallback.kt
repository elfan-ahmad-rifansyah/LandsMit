package id.dwiilham.landsmit.callback

import com.google.gson.annotations.SerializedName

class LocCallback {

    @SerializedName("Address")
    var address: AddressCallback? = null
}
