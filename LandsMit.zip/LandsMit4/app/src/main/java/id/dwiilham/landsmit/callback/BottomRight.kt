package id.dwiilham.landsmit.callback

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class BottomRight {

    @SerializedName("Latitude")
    @Expose
    private var latitude: Double? = null
    @SerializedName("Longitude")
    @Expose
    private var longitude: Double? = null

    fun getLatitude(): Double? {
        return latitude
    }

    fun setLatitude(latitude: Double?) {
        this.latitude = latitude
    }

    fun getLongitude(): Double? {
        return longitude
    }

    fun setLongitude(longitude: Double?) {
        this.longitude = longitude
    }
}