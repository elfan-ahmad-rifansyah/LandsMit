package id.dwiilham.landsmit.callback

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class MapReference {

    @SerializedName("ReferenceId")
    @Expose
    private var referenceId: String? = null
    @SerializedName("MapId")
    @Expose
    private var mapId: String? = null
    @SerializedName("MapVersion")
    @Expose
    private var mapVersion: String? = null
    @SerializedName("MapReleaseDate")
    @Expose
    private var mapReleaseDate: String? = null
    @SerializedName("Spot")
    @Expose
    private var spot: Double? = null
    @SerializedName("SideOfStreet")
    @Expose
    private var sideOfStreet: String? = null
    @SerializedName("CountryId")
    @Expose
    private var countryId: String? = null
    @SerializedName("CountyId")
    @Expose
    private var countyId: String? = null
    @SerializedName("DistrictId")
    @Expose
    private var districtId: String? = null
    @SerializedName("AddressId")
    @Expose
    private var addressId: String? = null
    @SerializedName("RoadLinkId")
    @Expose
    private var roadLinkId: String? = null

    fun getReferenceId(): String? {
        return referenceId
    }

    fun setReferenceId(referenceId: String?) {
        this.referenceId = referenceId
    }

    fun getMapId(): String? {
        return mapId
    }

    fun setMapId(mapId: String?) {
        this.mapId = mapId
    }

    fun getMapVersion(): String? {
        return mapVersion
    }

    fun setMapVersion(mapVersion: String?) {
        this.mapVersion = mapVersion
    }

    fun getMapReleaseDate(): String? {
        return mapReleaseDate
    }

    fun setMapReleaseDate(mapReleaseDate: String?) {
        this.mapReleaseDate = mapReleaseDate
    }

    fun getSpot(): Double? {
        return spot
    }

    fun setSpot(spot: Double?) {
        this.spot = spot
    }

    fun getSideOfStreet(): String? {
        return sideOfStreet
    }

    fun setSideOfStreet(sideOfStreet: String?) {
        this.sideOfStreet = sideOfStreet
    }

    fun getCountryId(): String? {
        return countryId
    }

    fun setCountryId(countryId: String?) {
        this.countryId = countryId
    }

    fun getCountyId(): String? {
        return countyId
    }

    fun setCountyId(countyId: String?) {
        this.countyId = countyId
    }

    fun getDistrictId(): String? {
        return districtId
    }

    fun setDistrictId(districtId: String?) {
        this.districtId = districtId
    }

    fun getAddressId(): String? {
        return addressId
    }

    fun setAddressId(addressId: String?) {
        this.addressId = addressId
    }

    fun getRoadLinkId(): String? {
        return roadLinkId
    }

    fun setRoadLinkId(roadLinkId: String?) {
        this.roadLinkId = roadLinkId
    }


}