package id.dwiilham.landsmit.callback


import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Location {
    @SerializedName("LocationId")
    @Expose
    private var locationId: String? = null
    @SerializedName("LocationType")
    @Expose
    private var locationType: String? = null
    @SerializedName("DisplayPosition")
    @Expose
    private var displayPosition: DisplayPosition? = null
    @SerializedName("NavigationPosition")
    @Expose
    private var navigationPosition: List<NavigationPosition?>? = null
    @SerializedName("MapView")
    @Expose
    private var mapView: MapView? = null
    @SerializedName("Address")
    @Expose
    private var address: Address? = null
    @SerializedName("MapReference")
    @Expose
    private var mapReference: MapReference? = null

    fun getLocationId(): String? {
        return locationId
    }

    fun setLocationId(locationId: String?) {
        this.locationId = locationId
    }

    fun getLocationType(): String? {
        return locationType
    }

    fun setLocationType(locationType: String?) {
        this.locationType = locationType
    }

    fun getDisplayPosition(): DisplayPosition? {
        return displayPosition
    }

    fun setDisplayPosition(displayPosition: DisplayPosition?) {
        this.displayPosition = displayPosition
    }

    fun getNavigationPosition(): List<NavigationPosition?>? {
        return navigationPosition
    }

    fun setNavigationPosition(navigationPosition: List<NavigationPosition?>?) {
        this.navigationPosition = navigationPosition
    }

    fun getMapView(): MapView? {
        return mapView
    }

    fun setMapView(mapView: MapView?) {
        this.mapView = mapView
    }

    fun getAddress(): Address? {
        return address
    }

    fun setAddress(address: Address?) {
        this.address = address
    }

    fun getMapReference(): MapReference? {
        return mapReference
    }

    fun setMapReference(mapReference: MapReference?) {
        this.mapReference = mapReference
    }
}