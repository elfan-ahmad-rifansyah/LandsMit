package id.dwiilham.landsmit.callback

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class MatchQuality {
    @SerializedName("Country")
    @Expose
    private var country: Double? = null
    @SerializedName("County")
    @Expose
    private var county: Double? = null
    @SerializedName("City")
    @Expose
    private var city: Double? = null
    @SerializedName("District")
    @Expose
    private var district: Double? = null
    @SerializedName("Subdistrict")
    @Expose
    private var subdistrict: Double? = null
    @SerializedName("Street")
    @Expose
    private var street: List<Double?>? = null
    @SerializedName("HouseNumber")
    @Expose
    private var houseNumber: Double? = null
    @SerializedName("PostalCode")
    @Expose
    private var postalCode: Double? = null

    fun getCountry(): Double? {
        return country
    }

    fun setCountry(country: Double?) {
        this.country = country
    }

    fun getCounty(): Double? {
        return county
    }

    fun setCounty(county: Double?) {
        this.county = county
    }

    fun getCity(): Double? {
        return city
    }

    fun setCity(city: Double?) {
        this.city = city
    }

    fun getDistrict(): Double? {
        return district
    }

    fun setDistrict(district: Double?) {
        this.district = district
    }

    fun getSubdistrict(): Double? {
        return subdistrict
    }

    fun setSubdistrict(subdistrict: Double?) {
        this.subdistrict = subdistrict
    }

    fun getStreet(): List<Double?>? {
        return street
    }

    fun setStreet(street: List<Double?>?) {
        this.street = street
    }

    fun getHouseNumber(): Double? {
        return houseNumber
    }

    fun setHouseNumber(houseNumber: Double?) {
        this.houseNumber = houseNumber
    }

    fun getPostalCode(): Double? {
        return postalCode
    }

    fun setPostalCode(postalCode: Double?) {
        this.postalCode = postalCode
    }
}