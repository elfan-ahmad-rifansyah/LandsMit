package id.dwiilham.landsmit.callback

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Address {
    @SerializedName("Label")
    @Expose
    private var label: String? = null
    @SerializedName("Country")
    @Expose
    private var country: String? = null
    @SerializedName("County")
    @Expose
    private var county: String? = null
    @SerializedName("City")
    @Expose
    private var city: String? = null
    @SerializedName("District")
    @Expose
    private var district: String? = null
    @SerializedName("Subdistrict")
    @Expose
    private var subdistrict: String? = null
    @SerializedName("Street")
    @Expose
    private var street: String? = null
    @SerializedName("HouseNumber")
    @Expose
    private var houseNumber: String? = null
    @SerializedName("PostalCode")
    @Expose
    private var postalCode: String? = null
    @SerializedName("AdditionalData")
    @Expose
    private var additionalData: List<AdditionalDatum?>? = null

    fun getLabel(): String? {
        return label
    }

    fun setLabel(label: String?) {
        this.label = label
    }

    fun getCountry(): String? {
        return country
    }

    fun setCountry(country: String?) {
        this.country = country
    }

    fun getCounty(): String? {
        return county
    }

    fun setCounty(county: String?) {
        this.county = county
    }

    fun getCity(): String? {
        return city
    }

    fun setCity(city: String?) {
        this.city = city
    }

    fun getDistrict(): String? {
        return district
    }

    fun setDistrict(district: String?) {
        this.district = district
    }

    fun getSubdistrict(): String? {
        return subdistrict
    }

    fun setSubdistrict(subdistrict: String?) {
        this.subdistrict = subdistrict
    }

    fun getStreet(): String? {
        return street
    }

    fun setStreet(street: String?) {
        this.street = street
    }

    fun getHouseNumber(): String? {
        return houseNumber
    }

    fun setHouseNumber(houseNumber: String?) {
        this.houseNumber = houseNumber
    }

    fun getPostalCode(): String? {
        return postalCode
    }

    fun setPostalCode(postalCode: String?) {
        this.postalCode = postalCode
    }

    fun getAdditionalData(): List<AdditionalDatum?>? {
        return additionalData
    }

    fun setAdditionalData(additionalData: List<AdditionalDatum?>?) {
        this.additionalData = additionalData
    }
}