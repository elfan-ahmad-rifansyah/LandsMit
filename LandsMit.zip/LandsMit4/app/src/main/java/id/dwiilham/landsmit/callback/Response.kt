package id.dwiilham.landsmit.callback

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class Response {

    @SerializedName("MetaInfo")
    @Expose
    private var metaInfo: MetaInfo? = null
    @SerializedName("View")
    @Expose
    private var view: List<View?>? = null

    fun getMetaInfo(): MetaInfo? {
        return metaInfo
    }

    fun setMetaInfo(metaInfo: MetaInfo?) {
        this.metaInfo = metaInfo
    }

    fun getView(): List<View?>? {
        return view
    }

    fun setView(view: List<View?>?) {
        this.view = view
    }

}