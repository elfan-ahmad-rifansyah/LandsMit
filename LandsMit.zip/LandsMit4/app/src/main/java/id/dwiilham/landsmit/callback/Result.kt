package id.dwiilham.landsmit.callback

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class Result {
    @SerializedName("Relevance")
    @Expose
    private var relevance: Double? = null
    @SerializedName("Distance")
    @Expose
    private var distance: Double? = null
    @SerializedName("MatchLevel")
    @Expose
    private var matchLevel: String? = null
    @SerializedName("MatchQuality")
    @Expose
    private var matchQuality: MatchQuality? = null
    @SerializedName("MatchType")
    @Expose
    private var matchType: String? = null
    @SerializedName("Location")
    @Expose
    private var location: Location? = null

    fun getRelevance(): Double? {
        return relevance
    }

    fun setRelevance(relevance: Double?) {
        this.relevance = relevance
    }

    fun getDistance(): Double? {
        return distance
    }

    fun setDistance(distance: Double?) {
        this.distance = distance
    }

    fun getMatchLevel(): String? {
        return matchLevel
    }

    fun setMatchLevel(matchLevel: String?) {
        this.matchLevel = matchLevel
    }

    fun getMatchQuality(): MatchQuality? {
        return matchQuality
    }

    fun setMatchQuality(matchQuality: MatchQuality?) {
        this.matchQuality = matchQuality
    }

    fun getMatchType(): String? {
        return matchType
    }

    fun setMatchType(matchType: String?) {
        this.matchType = matchType
    }

    fun getLocation(): Location? {
        return location
    }

    fun setLocation(location: Location?) {
        this.location = location
    }

}