package id.dwiilham.landsmit.rest

import id.dwiilham.landsmit.callback.Example
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface RestInterface {

    @GET("reversegeocode.json")
    fun getInfo(
        @Query("prox") prox: String,
        @Query("mode") mode: String,
        @Query("maxresults") maxResult: String,
        @Query("gen") gen: String,
        @Query("app_id") appId: String,
        @Query("app_code") appCode: String
    ): Call<Example>?
}